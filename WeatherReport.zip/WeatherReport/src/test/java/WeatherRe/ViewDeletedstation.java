package WeatherRe;
import static io.restassured.RestAssured.*;

import org.testng.annotations.Test;
public class ViewDeletedstation {
	@Test
	public void PostStation() {
		 given().baseUri("http://api.openweathermap.org/data/3.0/stations")
		.queryParam("appid","902fad458e0bb7173564ceecff8a3751")
		.when()
		.delete("http://api.openweathermap.org/data/3.0/stations/62e78fdb8885c200018f6961")
		.then().log().all();
		}

}
