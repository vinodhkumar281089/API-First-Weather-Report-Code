package WeatherRe;

import static io.restassured.RestAssured.*;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class PostWeather {
@Test(invocationCount=2)
public void PostStation() {
	RestAssured.given().queryParam("appid","902fad458e0bb7173564ceecff8a3751")
	.header("content-type","application/json").body("{\"external_id\": \"DEMO_TEST001\",\r\n"
	+ "  \"name\": \" Capgemini Weather \",\r\n"
	+ "  \"latitude\": 37.76,\r\n"
	+ "  \"longitude\": -12.43,\r\n"
	+ "  \"altitude\": 150}").post("http://api.openweathermap.org/data/3.0/stations").then().log().all();
	}
}
