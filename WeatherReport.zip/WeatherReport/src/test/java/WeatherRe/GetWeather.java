package WeatherRe;
import static io.restassured.RestAssured.*;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
public class GetWeather {
	@Test(enabled=true)
	
	public void PostStation() {
		given().queryParam("appid","902fad458e0bb7173564ceecff8a3751")
		.header("content-type","application/json").when()
		.get("http://api.openweathermap.org/data/3.0/stations/62e980118885c200018f69f9")
		.then().log().all().assertThat().statusCode(200);
		}

}
