package WeatherRe;
import static io.restassured.RestAssured.*;

import org.testng.annotations.Test;

import io.restassured.RestAssured;


public class InvalidAPI {
	@Test
	public void WithoutKey() {
	RestAssured.given().queryParam("appid","902fad458e0bb7173564ceecff8a375")
	.header("content-type","application/json")
	.body("{\"external_id\": \"DEMO_TEST001\",\r\n"
			+ "  \"name\": \" Delhi Weather \",\r\n"
			+ "  \"latitude\": 37.76,\r\n"
			+ "  \"longitude\": -122.43,\r\n"
			+ "  \"altitude\": 150}").get("http://api.openweathermap.org/data/3.0/stations")
	.then().log().all();
	}

}
